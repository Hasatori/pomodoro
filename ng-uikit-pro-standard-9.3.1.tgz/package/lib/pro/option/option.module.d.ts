export declare class MdbOptionModule {
}

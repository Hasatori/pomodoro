export declare class AutoFormatModule {
}

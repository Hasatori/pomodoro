export declare class StepperModule {
}

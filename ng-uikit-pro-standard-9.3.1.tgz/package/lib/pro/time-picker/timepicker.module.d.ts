export declare class TimePickerModule {
}

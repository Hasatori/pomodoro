export declare class MdbSelectModule {
}

export declare class ScrollSpyModule {
}

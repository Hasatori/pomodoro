export declare class MdbTimePickerModule {
}

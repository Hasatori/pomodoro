export declare class MdbTreeModule {
}

export declare class StickyHeaderModule {
}

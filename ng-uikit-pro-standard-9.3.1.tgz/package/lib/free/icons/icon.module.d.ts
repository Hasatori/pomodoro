export declare class IconsModule {
}

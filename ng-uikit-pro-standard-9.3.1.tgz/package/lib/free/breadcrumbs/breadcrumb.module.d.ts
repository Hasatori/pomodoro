export declare class BreadcrumbModule {
}
